import { Component } from '@angular/core';

@Component({
  selector: 'app-customer-details',
  imports: [],
  templateUrl: './customer-details.component.html',
  styles: ``
})
export class CustomerDetailsComponent {

}
