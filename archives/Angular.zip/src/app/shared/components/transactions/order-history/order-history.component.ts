import { Component } from '@angular/core';

@Component({
  selector: 'app-order-history',
  imports: [],
  templateUrl: './order-history.component.html',
  styles: ``
})
export class OrderHistoryComponent {

}
