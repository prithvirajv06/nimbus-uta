import { Component } from '@angular/core';

@Component({
  selector: 'app-transaction-header',
  imports: [],
  templateUrl: './transaction-header.component.html',
  styles: ``
})
export class TransactionHeaderComponent {

}
