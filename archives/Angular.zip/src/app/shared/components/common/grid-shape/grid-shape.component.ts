import { Component } from '@angular/core';

@Component({
  selector: 'app-grid-shape',
  imports: [],
  templateUrl: './grid-shape.component.html',
  styles: ``
})
export class GridShapeComponent {

}
