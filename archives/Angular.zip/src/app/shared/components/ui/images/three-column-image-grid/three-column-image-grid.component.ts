import { Component } from '@angular/core';

@Component({
  selector: 'app-three-column-image-grid',
  imports: [],
  templateUrl: './three-column-image-grid.component.html',
  styles: ``
})
export class ThreeColumnImageGridComponent {

}
