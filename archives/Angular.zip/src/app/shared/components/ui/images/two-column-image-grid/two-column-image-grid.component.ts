import { Component } from '@angular/core';

@Component({
  selector: 'app-two-column-image-grid',
  imports: [],
  templateUrl: './two-column-image-grid.component.html',
  styles: ``
})
export class TwoColumnImageGridComponent {

}
