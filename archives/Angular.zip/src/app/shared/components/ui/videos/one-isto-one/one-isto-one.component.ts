import { Component } from '@angular/core';

@Component({
  selector: 'app-one-isto-one',
  imports: [],
  templateUrl: './one-isto-one.component.html',
  styles: ``
})
export class OneIstoOneComponent {

}
