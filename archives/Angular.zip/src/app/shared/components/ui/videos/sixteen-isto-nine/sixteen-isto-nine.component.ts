import { Component } from '@angular/core';

@Component({
  selector: 'app-sixteen-isto-nine',
  imports: [],
  templateUrl: './sixteen-isto-nine.component.html',
  styles: ``
})
export class SixteenIstoNineComponent {

}
