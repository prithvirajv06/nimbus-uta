import { Component } from '@angular/core';

@Component({
  selector: 'app-twentyone-isto-nine',
  imports: [],
  templateUrl: './twentyone-isto-nine.component.html',
  styles: ``
})
export class TwentyoneIstoNineComponent {

}
