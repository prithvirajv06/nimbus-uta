import { Component } from '@angular/core';

@Component({
  selector: 'app-simulation-log',
  imports: [],
  templateUrl: './simulation-log.component.html',
  styleUrl: './simulation-log.component.css',
})
export class SimulationLogComponent {

}
